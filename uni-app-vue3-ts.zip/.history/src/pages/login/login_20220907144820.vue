<template>
	<view class="login_index">
		<view class="is_lab" @click="login_submit">我是登陆界面 登陆吧</view>

		<view class="is_lab" @tap="is_init">back</view>
	</view>
</template>

<script setup lang="ts">
	import { ref } from 'vue'
	import { onLoad } from '@dcloudio/uni-app'
	import { useRouter } from '@/router/index'

	const router = useRouter()
	const username = ref('admin')
	const password = ref('admin')

	onLoad(() => {
		isInit()
	})

	const isInit = () => {
		uni.showModal({
			title: '系统提示',
			content: 'back?',
			success: () => {
				router
					.hook(() => console.log('test hook1'))
					.gotoRouter('index', { test: 'test index' })
					.hook(() => console.log('test hook2'))
			}
		})
	}

	const loginSubmit = () => {
		this.is_vuex.commit('user_vuex/set_user_role', ['user'])
		this.is_tools.to_showModal('登陆成功', '系统提示', () => this.is_init())
	}
</script>

<style scoped>
	.is_lab {
		margin-bottom: 50upx;
		color: red;
	}
</style>
