<template>
	<view>test</view>
</template>
