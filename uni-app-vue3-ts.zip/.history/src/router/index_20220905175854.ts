import type { pagesJson_DTYPE, pages_DTYPE, tabBarList_DTYPE, subPackages_DTYPE } from '#/router/index'

var pages_JSON = ''

type newPagesJsonDTYPE = {
	[key in string]: any
} & pagesJson_DTYPE

const router: newPagesJsonDTYPE = { pages: [] }
const shallow: Array<any> = []

// webpack str json
const pageJson = JSON.parse(pages_JSON) as pagesJson_DTYPE
const tabBarJson = pageJson.tabBar?.list as Array<tabBarList_DTYPE>

for (let tabbar of tabBarJson) {
	tabbar.iconPath = `/${tabbar.iconPath}`
	tabbar.pagePath = `/${tabbar.pagePath}`
	tabbar.selectedIconPath = `/${tabbar.selectedIconPath}`
}

// 转换为router键值格式
type mainRouter = { [key in string]: pages_DTYPE }
const forRouter = (list: Array<any>, space: string): pages_DTYPE | subPackages_DTYPE | any => {
	let main: mainRouter = {}
	list.forEach((page) => {
		let info = page,
			path = info.path,
			spl = path.split('/')
		info.path = `${space !== 'pages' ? `/${space}` : ''}/${path}`
		const name = spl[spl.length - 1]
		main[name] = info
		info.name = name
		info.space = space
		shallow.push(info)
	})
	return main
}

// 主包
router['pages'] = forRouter(pageJson.pages, 'pages')
// 子包
pageJson.subPackages?.forEach(({ root, pages }) => (router[root] = forRouter(pages, root)))
// 广度列表
router['shallow'] = shallow
// tabbar
router['tablist'] = tabBarJson

console.log('router chunks=', router)

export default router
