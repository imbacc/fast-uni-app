import { METHOD } from '../cfg.js'

// 模块api
export default {
	get_user: ['api/user', METHOD.GET]
}
