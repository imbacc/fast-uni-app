import { METHOD } from '../cfg.js'

// 模块api
export default {
	get_test: 'api/get_test',
	get_test222: ['api/get_test/:id', METHOD.GET],
	get_test333: 'api/get_test/three'
}
