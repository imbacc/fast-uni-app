import requestAction from '@/common/tools/cmake_zinterceptor.js'

import { METHOD } from '../cfg.js'

// 模块api
const api = {
	getUser: ['api/user', METHOD.GET]
}

export const getUser = () => requestAction(...api.getUser)
