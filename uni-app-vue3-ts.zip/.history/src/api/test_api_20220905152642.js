import requestAction from '@/common/tools/cmake_zinterceptor.js'

import { METHOD } from '../cfg.js'

// 模块api
const api = {
	getTest: ['api/get_test', METHOD.GET],
	getTest222: ['api/get_test/:id', METHOD.GET],
	getTest333: ['api/get_test/three', METHOD.GET]
}

export const getTest = () => requestAction(...api.getTest)
