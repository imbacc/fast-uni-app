import requestAction from '@/common/tools/cmake_zinterceptor.js'

import { METHOD } from '../cfg.js'

// 模块api
const api = {
	getUser: ['api/user', METHOD.GET]
}

export const getTest = () => requestAction(...api.getTest)
export const getTest222 = () => requestAction(...api.getTest222)
export const getTest333 = () => requestAction(...api.getTest333)
