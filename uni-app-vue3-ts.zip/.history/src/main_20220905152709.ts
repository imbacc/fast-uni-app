import { createSSRApp } from 'vue'
import App from './App.vue'

import store from '@/store/index' //导入vuex
import router from '@/tools/cmakeRouter' //封装跳转
import tools from '@/tools/cmakeTools' //自定义函数
import routerChunks from '@/router/index' //导入router
import { isDev } from '@/config/cfg'

export function createApp() {
	const app = createSSRApp(App)

	// //导入组件全局
	// import skeleton from '@/components/skeleton/skeleton.vue'
	// app.component('skeleton', skeleton)

	//导入Minix全局
	// import goto_page from '@/common/minix/module/goto_page.js';		//跳转
	// app.mixin(goto_page)

	app.config.devtools = isDev

	// 处理错误
	// app.config.errorHandler = (err, vm, info) => {
	//   // `info` 是 Vue 特定的错误信息，比如错误所在的生命周期钩子
	// }

	//
	// 全局注册组件
	// app.component('component-a', {
	// mounted() {
	// 	console.log(this.foo) // 'bar'
	// }
	// })

	// 全局注册组件指令
	// app.directive('focus', {
	// mounted() {
	// 	el => el.focus()
	// }
	//   mounted: el => el.focus()
	// })

	return {
		app
	}
}
