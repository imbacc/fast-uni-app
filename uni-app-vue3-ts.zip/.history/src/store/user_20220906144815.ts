import { setCacheLoca, getCacheLoca, delCache } from 'imba-cache'
import { defineStore } from 'pinia'

const TOKEN = uni.getStorageSync('token') || false
const USER_INFO = getCacheLoca('userInfo') || false
const USER_ROLE = getCacheLoca('userRole') || []

export const useUserStore = defineStore('user', {
	state: () => {
		return {
			token: TOKEN, // 用户token
			userInfo: USER_INFO, // 用户信息
			userRole: USER_ROLE //用户角色权限
		}
	},
	getters: {
		hasLogin: (state) => state.token || state.userInfo || false,
		getRole: (state) => state.userRole
	},
	actions: {
		setCache(key, val) {
			this.$patch({ [key]: val })
			setCacheLoca(key, val)
		},
		setRole(role) {
			this.userRole = [...new Set([...this.userRole, ...role])]
			setCacheLoca('userRole', this.userRole)
		},
		setLogout(state) {
			this.$patch({ token: '', userInfo: false, userRole: [] })
			delCache('token')
			delCache('userInfo')
			delCache('userRole')
		}
	}
})
