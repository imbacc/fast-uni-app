import { createSSRApp } from 'vue'
import App from './App.vue'

import store from '@/store/index.js' //导入vuex
import router from '@/tools/cmake_router.js' //封装跳转
import api from '@/config/api.js' //封装请求
import tools from '@/tools/cmake_tools.js' //自定义函数
import routerChunks from '@/router/index.js' //导入router
import { isDev } from '@/config/cfg.js'

export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
