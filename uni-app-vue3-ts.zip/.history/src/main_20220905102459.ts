import { createSSRApp } from 'vue'
import App from './App.vue'

import store from '@/common/store/index.js' //导入vuex
import router from '@/common/tools/cmake_router.js' //封装跳转
import api from '@/common/config/api.js' //封装请求
import tools from '@/common/tools/cmake_tools.js' //自定义函数
import routerChunks from '@/common/router/index.js' //导入router
import { isDev } from '@/common/config/cfg.js'

export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
