import { createSSRApp } from 'vue'
import App from './App.vue'

import store from '@/store/index' //导入vuex
import router from '@/tools/cmakeRouter' //封装跳转
import tools from '@/tools/cmakeTools' //自定义函数
import routerChunks from '@/router/index' //导入router

export function createApp() {
	const app = createSSRApp(App)

	// //导入组件全局
	// import skeleton from '@/components/skeleton/skeleton.vue'
	// app.component('skeleton', skeleton)

	//导入Minix全局
	// import goto_page from '@/common/minix/module/goto_page.js';		//跳转
	// app.mixin(goto_page)

	// 处理错误
	// app.config.errorHandler = (err, vm, info) => {
	//   // `info` 是 Vue 特定的错误信息，比如错误所在的生命周期钩子
	// }

	return {
		app
	}
}
