import type { METHOD_DTYPE } from '#/global'

// 请求体方式
const METHOD: METHOD_DTYPE = {
	POST: 'POST',
	GET: 'GET',
	PUT: 'PUT',
	OPTIONS: 'OPTIONS'
}

const timeOut = 3000
const env = process.env
const mode = env.MODE // development or production
const isDev = Boolean(mode === 'development') // 是否是开发环境
const isCdn = 'https://xxx/static/img/'
const pageKey = 'page'
const sizeKey = 'size'

export { METHOD, env, mode, isDev, isCdn, timeOut, pageKey, sizeKey, sysConfig }
