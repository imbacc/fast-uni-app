import type { AxiosRequestHeaders } from 'axios'

export type repeatRecord_DTYPE = { [key in string]: string | boolean }
export type repeatRecord_KEYOF = keyof repeatRecord_DTYPE
export type requestUseData_DTYPE = {
	_noToken?: boolean
	_formData?: boolean
	_header?: AxiosRequestHeaders
}
