export type globalStyle_DTYPE = {
	/**
	 * 描述: 导航栏背景颜色（同状态栏背景色）
	 * 平台差异说明: APP与H5为#F7F7F7，小程序平台请参考相应小程序文档
	 */
	navigationBarBackgroundColor?: string | '#F7F7F7'
	/**
	 * 描述: 导航栏标题颜色及状态栏前景颜色，仅支持 black/white
	 * 平台差异说明: -
	 */
	navigationBarTextStyle?: 'white' | 'black'
	/**
	 * 描述: 导航栏标题文字内容
	 * 平台差异说明: -
	 */
	navigationBarTitleText?: string
	/**
	 * 描述: 导航栏标题文字内容
	 * 平台差异说明: -
	 */
	navigationStyle?: 'default' | 'custom'
	/**
	 * 描述: 下拉显示出来的窗口的背景色
	 * 平台差异说明: 微信小程序
	 */
	backgroundColor?: string | '#ffffff'
}
export type pages_DTYPE = {}
export type easycom_DTYPE = {}
export type tabBar_DTYPE = {}
export type condition_DTYPE = {}
export type subPackages_DTYPE = {}
export type preloadRule_DTYPE = {}
export type leftWindow_DTYPE = {}
export type topWindow_DTYPE = {}
export type rightWindow_DTYPE = {}
export type uniIdRouter_DTYPE = {}

export type pagesJson_DTYPE = {
	globalStyle: globalStyle_DTYPE
	pages: Array<pages_DTYPE>
	easycom: easycom_DTYPE
	tabBar: tabBar_DTYPE
	condition: condition_DTYPE
	subPackages: Array<subPackages_DTYPE>
	preloadRule: preloadRule_DTYPE
	workers: string
	leftWindow: leftWindow_DTYPE
	topWindow: topWindow_DTYPE
	rightWindow: rightWindow_DTYPE
	uniIdRouter: uniIdRouter_DTYPE
}
