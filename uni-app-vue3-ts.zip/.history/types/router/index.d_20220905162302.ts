export type globalStyle_DTYPE = {
	/**
	 * 描述: 导航栏背景颜色（同状态栏背景色）
	 * 平台差异说明: APP与H5为#F7F7F7，小程序平台请参考相应小程序文档
	 */
	navigationBarBackgroundColor?: string | '#F7F7F7'
	/**
	 * 描述: 导航栏标题颜色及状态栏前景颜色，仅支持 black/white
	 * 平台差异说明: -
	 */
	navigationBarTextStyle?: 'white' | 'black'
	/**
	 * 描述: 导航栏标题文字内容
	 * 平台差异说明: -
	 */
	navigationBarTitleText?: string
	/**
	 * 描述: 导航栏样式，仅支持 default/custom。custom即取消默认的原生导航栏，需看使用注意https://uniapp.dcloud.net.cn/collocation/pages.html#customnav
	 * 平台差异说明: -
	 */
	navigationStyle?: 'default' | 'custom'
	/**
	 * 描述: 下拉显示出来的窗口的背景色
	 * 平台差异说明: 微信小程序
	 */
	backgroundColor?: string | '#ffffff'
	/**
	 * 描述: 下拉 loading 的样式，仅支持 dark / light
	 * 平台差异说明: 微信小程序
	 */
	backgroundTextStyle?: 'dark' | 'light'
	/**
	 * 描述: 是否开启下拉刷新，详见页面生命周期。https://uniapp.dcloud.net.cn/tutorial/page.html#lifecycle
	 * 平台差异说明: -
	 */
	enablePullDownRefresh?: boolean
	/**
	 * 描述: 页面上拉触底事件触发时距页面底部距离，单位只支持px，详见页面生命周期https://uniapp.dcloud.net.cn/tutorial/page.html#lifecycle
	 * 平台差异说明: -
	 */
	onReachBottomDistance?: number | 50
	/**
	 * 描述: 顶部窗口的背景色（bounce回弹区域）
	 * 平台差异说明: 仅 iOS 平台
	 */
	backgroundColorTop?: string | '#ffffff'
	/**
	 * 描述: 底部窗口的背景色（bounce回弹区域）
	 * 平台差异说明: 仅 iOS 平台
	 */
	backgroundColorBottom?: string | '#ffffff'
	/**
	 * 描述: 导航栏图片地址（替换当前文字标题），支付宝小程序内必须使用https的图片链接地址
	 * 平台差异说明: 支付宝小程序、H5、APP
	 */
	titleImage?: string
	/**
	 * 描述: 导航栏整体（前景、背景）透明设置。支持 always 一直透明 / auto 滑动自适应 / none 不透明
	 * 平台差异说明: 支付宝小程序、H5、APP
	 */
	transparentTitle?: 'always' | 'auto' | 'none'
	/**
	 * 描述: 导航栏点击穿透
	 * 平台差异说明: 支付宝小程序、H5
	 */
	titlePenetrate?: string | 'NO'
	/**
	 * 描述: 横屏配置，屏幕旋转设置，仅支持 auto / portrait / landscape 详见 响应显示区域变化https://developers.weixin.qq.com/miniprogram/dev/framework/view/resizable.html
	 * 平台差异说明: 支付宝小程序、H5
	 */
	pageOrientation?: 'auto' | 'portrait' | 'landscape'
	/**
	 * 描述: 窗口显示的动画效果，详见：窗口动画https://uniapp.dcloud.net.cn/api/router#animation
	 * 平台差异说明: App
	 */
	animationType?: Omit<keyof UniApp.NavigateToOptions, 'animationType'>
}
export type pages_DTYPE = {}
export type easycom_DTYPE = {}
export type tabBar_DTYPE = {}
export type condition_DTYPE = {}
export type subPackages_DTYPE = {}
export type preloadRule_DTYPE = {}
export type leftWindow_DTYPE = {}
export type topWindow_DTYPE = {}
export type rightWindow_DTYPE = {}
export type uniIdRouter_DTYPE = {}

export type pagesJson_DTYPE = {
	globalStyle: globalStyle_DTYPE
	pages: Array<pages_DTYPE>
	easycom: easycom_DTYPE
	tabBar: tabBar_DTYPE
	condition: condition_DTYPE
	subPackages: Array<subPackages_DTYPE>
	preloadRule: preloadRule_DTYPE
	workers: string
	leftWindow: leftWindow_DTYPE
	topWindow: topWindow_DTYPE
	rightWindow: rightWindow_DTYPE
	uniIdRouter: uniIdRouter_DTYPE
}
