export type token_TYPE = string
export type userInfo_TYPE = {}
export type userRole_TYPE = Array<string>
export type user_DTYPE = token_TYPE & userInfo_TYPE & userRole_TYPE
