type token = string
type userInfo = {}
type userRole = Array<string>
type user_DTYPE = token & userInfo & userRole
