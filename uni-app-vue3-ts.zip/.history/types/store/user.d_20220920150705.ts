export type token_TYPE = string
export type userInfo_TYPE = {}
export type userRole_TYPE = Array<string>
export type user_DTYPE = {
	token: token_TYPE
	userInfo: userInfo_TYPE
	userRole: userRole_TYPE
}
