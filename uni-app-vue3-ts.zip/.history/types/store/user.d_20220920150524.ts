type token_TYPE = string
type userInfo_TYPE = {}
type userRole_TYPE = Array<string>
type user_DTYPE = token_TYPE & userInfo_TYPE & userRole_TYPE
