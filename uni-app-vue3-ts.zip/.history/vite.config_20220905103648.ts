import { defineConfig } from 'vite'
import uni from '@dcloudio/vite-plugin-uni'

// plugin
import { VITE_USE_MOCK, VITE_BUILD_GZIP } from './src/common/config/cfg.js'
import { viteMockServe } from 'vite-plugin-mock' // mock
import gzipPlugin from 'rollup-plugin-gzip' //Gzip
import windicssPlugin from 'vite-plugin-windicss' // windicss
import compressionPlugin from 'vite-plugin-compression' // 使用gzip或brotli来压缩资源
import componentsPlugin from './vite-plugin/vite-plugin-components.js' // Vite 的按需组件自动导入
import htmlInjectPlugin from './vite-plugin/vite-plugin-htmlInject.js' //html inject
import vitePluginRouterJson from './vite-plugin/vite-plugin-routerJson.js'

// https://vitejs.dev/config/
export default defineConfig({
	plugins: [uni()]
})
